#!/bin/bash
# =============================================================================
# Retencion FIFO del log de instancia (teaspeak_logs) por tamano en disco.
#
# Cuando la base de logs supera el tope, borra los registros MAS ANTIGUOS
# (FIFO) hasta bajar de un nivel bajo, y ejecuta VACUUM FULL para devolver el
# espacio al disco de verdad (un DELETE normal en Postgres NO encoge el fichero).
#
# Sobre "detener servicios": VACUUM FULL bloquea brevemente SOLO las tablas de
# la base de logs. El servidor de voz, los clientes, YaTQA y la base principal
# (teaspeak) NO se ven afectados: viven en otra base y en la red. Las escrituras
# de log son asincronas y simplemente se encolan mientras dura la operacion.
#
# Pensado para ejecutarse por cron. Idempotente y seguro de correr en cualquier
# momento.
# =============================================================================
set -uo pipefail

# ------- configuracion (el instalador la sobreescribe) -------
PGDATABASE="${TEASPEAK_LOGS_DB:-teaspeak_logs}"
PGUSER="${TEASPEAK_LOGS_USER:-postgres}"          # se ejecuta como el superusuario local por defecto
CAP_GB="${TEASPEAK_LOGS_CAP_GB:-25}"              # tope duro en GB
LOW_WATER_FRACTION="${TEASPEAK_LOGS_LOW_WATER:-0.80}"  # bajar hasta el 80% del tope
LOG_FILE="${TEASPEAK_LOGS_RETENTION_LOG:-/var/log/teaspeak-logs-retention.log}"

# psql como el superusuario del sistema postgres, sin contrasena (peer auth local)
psql_db() { sudo -u postgres psql -d "$PGDATABASE" -tAc "$1" 2>/dev/null; }

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"; }

# CAP_BYTES permite fijar el tope directamente en bytes (util para pruebas); si no,
# se deriva de CAP_GB.
cap_bytes="${TEASPEAK_LOGS_CAP_BYTES:-$(( CAP_GB * 1024 * 1024 * 1024 ))}"
low_water=$(awk "BEGIN{printf \"%d\", $cap_bytes * $LOW_WATER_FRACTION}")

current=$(psql_db "SELECT pg_database_size('${PGDATABASE}')")
if [[ -z "${current}" ]]; then
    log "ERROR: no se pudo consultar el tamano de ${PGDATABASE} (¿existe? ¿Postgres arriba?)"
    exit 1
fi

human() { awk "BEGIN{printf \"%.2f GB\", $1/1073741824}"; }

if (( current <= cap_bytes )); then
    log "OK: ${PGDATABASE} en $(human "$current") (tope ${CAP_GB} GB). Nada que borrar."
    exit 0
fi

log "Tope superado: ${PGDATABASE} en $(human "$current") > ${CAP_GB} GB. Iniciando poda FIFO."

# Fraccion de filas a eliminar para acercarnos al nivel bajo en una sola pasada.
# Se acota a [0.05, 0.60] para no borrar de golpe ni quedarnos cortos.
fraction=$(awk "BEGIN{f=1-($low_water/$current); if(f<0.05)f=0.05; if(f>0.60)f=0.60; printf \"%.4f\", f}")
log "Eliminando aproximadamente el $(awk "BEGIN{printf \"%.0f\", $fraction*100}")% mas antiguo de cada tabla de log."

# Todas las tablas de log (logs_*) tienen una columna "timestamp" (epoch ms).
tables=$(psql_db "SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename LIKE 'logs\\_%'")
if [[ -z "${tables}" ]]; then
    log "No hay tablas logs_* todavia. Nada que hacer."
    exit 0
fi

total_deleted=0
while IFS= read -r table; do
    [[ -z "${table}" ]] && continue
    rows=$(psql_db "SELECT count(*) FROM \"${table}\"")
    [[ -z "${rows}" || "${rows}" -eq 0 ]] && continue

    to_delete=$(awk "BEGIN{printf \"%d\", $rows * $fraction}")
    [[ "${to_delete}" -le 0 ]] && continue

    # FIFO: borrar las filas mas antiguas por timestamp, identificadas por ctid.
    deleted=$(psql_db "WITH victims AS (
                           SELECT ctid FROM \"${table}\" ORDER BY \"timestamp\" ASC LIMIT ${to_delete}
                       )
                       DELETE FROM \"${table}\" WHERE ctid IN (SELECT ctid FROM victims)
                       RETURNING 1" | wc -l)
    total_deleted=$(( total_deleted + deleted ))
    log "  ${table}: borradas ${deleted} filas (de ${rows})."
done <<< "${tables}"

log "Compactando (VACUUM FULL) para reclamar espacio en disco..."
sudo -u postgres psql -d "$PGDATABASE" -c "VACUUM (FULL, ANALYZE);" >/dev/null 2>&1

after=$(psql_db "SELECT pg_database_size('${PGDATABASE}')")
log "Poda completada: ${total_deleted} filas eliminadas. Tamano $(human "$current") -> $(human "$after")."
exit 0
