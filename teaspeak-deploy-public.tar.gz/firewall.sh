#!/bin/bash
# =============================================================================
# Firewall (iptables) para TeaSpeak - version PostgreSQL / Debian 11
#
# Adaptado del firewall de produccion. Cambios respecto al original:
#   - Puertos de voz y whitelists/blacklist como VARIABLES (edita el bloque de
#     abajo). El rango de voz DEBE coincidir con los puertos de tus servidores
#     virtuales (en el config, voice.default_port es solo el punto de partida).
#   - PostgreSQL (5432) NUNCA se abre al publico: escucha solo en localhost.
#   - El rate-limit UDP del original usaba "-m recent --hitcount 100", que NO
#     funciona: el modulo recent solo recuerda 20 paquetes por IP, asi que ese
#     contador nunca llega a 100 y la regla no hace nada. Aqui se usa hashlimit,
#     que limita las conexiones NUEVAS por IP sin afectar al trafico de voz ya
#     establecido.
# =============================================================================
set -uo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
log_ok()   { echo -e "  [${GREEN}OK${NC}] $1"; }
log_info() { echo -e "  [${CYAN}INFO${NC}] $1"; }
step()     { echo -e "\n${CYAN}>>>${NC} $1"; }

[[ $EUID -ne 0 ]] && { echo -e "${RED}[ERROR] Ejecuta como root.${NC}"; exit 1; }

# ============================ CONFIGURACION ============================
# IPs con acceso a SSH (22). Separadas por espacios. Vacio = abierto a todos (no recomendado).
WHITELIST_SSH="${WHITELIST_SSH:-172.216.237.49}"

# IPs con acceso al ServerQuery (10101). El query queda CERRADO al publico.
WHITELIST_QUERY="${WHITELIST_QUERY:-172.216.237.49 23.26.135.58}"

# IPs bloqueadas explicitamente en la frontera.
BLACKLIST_IPS="${BLACKLIST_IPS:-177.26.255.242 172.59.187.147 172.59.188.223 172.59.189.210 172.56.16.242 172.59.190.249}"

# Rango de puertos de VOZ (UDP). Debe cubrir los puertos de tus servidores virtuales.
UDP_PORTS="${UDP_PORTS:-10200:10225}"

TCP_FILES="${TCP_FILES:-30303}"    # transferencia de ficheros
TCP_QUERY="${TCP_QUERY:-10101}"    # ServerQuery
SSH_PORT="${SSH_PORT:-22}"

# Conexiones concurrentes maximas por IP en el puerto de ficheros
FILES_CONNLIMIT="${FILES_CONNLIMIT:-10}"
# Conexiones de voz NUEVAS por segundo por IP (rafaga)
VOICE_NEW_PER_SEC="${VOICE_NEW_PER_SEC:-10}"
VOICE_NEW_BURST="${VOICE_NEW_BURST:-30}"
# ======================================================================

clear
echo -e "${CYAN}${BOLD}========================================================"
echo -e "        FIREWALL TEASPEAK (PostgreSQL / Debian 11)"
echo -e "========================================================${NC}"

step "Politicas por defecto (rechazar todo lo entrante no autorizado)"
iptables -F
iptables -X
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT
log_ok "INPUT/FORWARD = DROP, OUTPUT = ACCEPT"

step "Loopback y estado de conexiones"
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -m conntrack --ctstate INVALID -j DROP
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
log_ok "Establecidas/relacionadas permitidas; invalidas descartadas"
log_info "PostgreSQL (5432) NO se abre: escucha solo en localhost."

step "Blacklist"
for ip in $BLACKLIST_IPS; do
    iptables -A INPUT -s "$ip" -j DROP
    echo -e "  - ${RED}$ip${NC} bloqueada"
done

step "SSH ($SSH_PORT) - solo whitelist"
if [[ -z "${WHITELIST_SSH// }" ]]; then
    iptables -A INPUT -p tcp --dport "$SSH_PORT" -j ACCEPT
    log_info "SSH ABIERTO a todos (no hay whitelist definida)"
else
    for ip in $WHITELIST_SSH; do
        iptables -A INPUT -p tcp -s "$ip" --dport "$SSH_PORT" -j ACCEPT
        echo -e "  - SSH permitido a ${YELLOW}$ip${NC}"
    done
fi

step "ServerQuery ($TCP_QUERY) - solo whitelist"
for ip in $WHITELIST_QUERY; do
    iptables -A INPUT -p tcp -s "$ip" --dport "$TCP_QUERY" -j ACCEPT
    echo -e "  - Query permitido a ${YELLOW}$ip${NC}"
done

step "Voz UDP ($UDP_PORTS) - publico con rate-limit de conexiones nuevas"
# hashlimit cuenta por IP de origen; solo limita paquetes NUEVOS (no molesta a
# los flujos de voz ya establecidos, que pasan por la regla de estado de arriba).
iptables -A INPUT -p udp --dport "$UDP_PORTS" -m conntrack --ctstate NEW \
    -m hashlimit --hashlimit-name ts_voice \
    --hashlimit-mode srcip \
    --hashlimit-above "${VOICE_NEW_PER_SEC}/sec" --hashlimit-burst "${VOICE_NEW_BURST}" \
    -j DROP
iptables -A INPUT -p udp --dport "$UDP_PORTS" -j ACCEPT
log_ok "Voz abierta; maximo ${VOICE_NEW_PER_SEC} conexiones nuevas/seg por IP (rafaga ${VOICE_NEW_BURST})"

step "Transferencia de ficheros ($TCP_FILES) - publico con limite de conexiones"
iptables -A INPUT -p tcp --dport "$TCP_FILES" -m connlimit --connlimit-above "${FILES_CONNLIMIT}" -j REJECT
iptables -A INPUT -p tcp --dport "$TCP_FILES" -j ACCEPT
log_ok "Ficheros abiertos; maximo ${FILES_CONNLIMIT} conexiones concurrentes por IP"

step "ICMP (ping) limitado"
iptables -A INPUT -p icmp --icmp-type echo-request -m limit --limit 1/s --limit-burst 5 -j ACCEPT
iptables -A INPUT -p icmp -j DROP
log_ok "Ping limitado a 1/seg (rafaga 5)"

step "Persistiendo reglas"
mkdir -p /etc/iptables
if command -v netfilter-persistent >/dev/null 2>&1; then
    netfilter-persistent save >/dev/null 2>&1
else
    iptables-save > /etc/iptables/rules.v4
fi
log_ok "Reglas guardadas (se restauran al arrancar)"

echo ""
echo -e "${GREEN}${BOLD}Firewall aplicado.${NC}"
log_info "SSH ($SSH_PORT) y Query ($TCP_QUERY): CERRADOS al publico (solo whitelist)."
log_info "Voz ($UDP_PORTS) y Ficheros ($TCP_FILES): ABIERTOS con rate-limit."
log_info "PostgreSQL (5432): solo localhost, no expuesto."
log_info "IPs en blacklist: $(echo $BLACKLIST_IPS | wc -w)"
echo ""
echo -e "${YELLOW}Recuerda: UDP_PORTS ($UDP_PORTS) debe coincidir con los puertos de tus servidores virtuales.${NC}"
