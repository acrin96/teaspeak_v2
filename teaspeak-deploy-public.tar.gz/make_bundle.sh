#!/bin/bash
# =============================================================================
# Ensambla el bundle desplegable desde el arbol ya compilado.
#
# Ejecutar en la maquina de build (Debian 11) DESPUES de compilar el servidor.
# Produce deploy/postgres-debian11/bundle/ con todo lo que install.sh necesita.
#
# Uso:  bash make_bundle.sh [ruta-raiz-del-arbol]
#       (por defecto asume que este script vive en deploy/postgres-debian11/)
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="${1:-$(cd "${SCRIPT_DIR}/../.." && pwd)}"
BUNDLE="${SCRIPT_DIR}/bundle"

ENV_DIR="${ROOT}/TeaSpeak/server/environment"
BIN="${ENV_DIR}/TeaSpeakServer"
RTC="${ROOT}/TeaSpeak/rtclib/libteaspeak_rtc.so"
MUSIC="${ROOT}/TeaSpeak/MusicBot/libs/libTeaMusic.so"

echo "=== Verificando artefactos ==="
[[ -f "${BIN}" ]]   || { echo "falta el binario: ${BIN} (¿compilaste?)"; exit 1; }
[[ -f "${RTC}" ]]   || { echo "falta librtc: ${RTC}"; exit 1; }
[[ -f "${MUSIC}" ]] || { echo "falta libTeaMusic: ${MUSIC}"; exit 1; }
[[ -d "${ENV_DIR}/resources" ]] || { echo "faltan resources en ${ENV_DIR}"; exit 1; }
echo "  binario, librtc, libTeaMusic y resources presentes"

echo "=== Comprobando compatibilidad glibc del binario ==="
sys=$(ldd --version | head -1 | grep -oE '[0-9]+\.[0-9]+$')
req=$(strings -a "${BIN}" | grep -oE '^GLIBC_2\.[0-9]+$' | sed 's/GLIBC_//' | sort -t. -k2,2n | tail -1)
echo "  sistema: glibc ${sys}, binario exige: glibc ${req:-ninguna}"
if [[ -n "${req}" ]] && [[ "${req#*.}" -gt "${sys#*.}" ]]; then
    echo "  AVISO: el binario exige una glibc mas nueva que la del sistema de destino."
fi

echo "=== Armando ${BUNDLE} ==="
rm -rf "${BUNDLE}"
mkdir -p "${BUNDLE}/libs"

cp "${BIN}"   "${BUNDLE}/TeaSpeakServer"
cp "${RTC}"   "${BUNDLE}/libteaspeak_rtc.so"
cp "${MUSIC}" "${BUNDLE}/libTeaMusic.so"
# copia tambien en libs/ por si se prefiere ese layout
cp "${RTC}" "${MUSIC}" "${BUNDLE}/libs/" 2>/dev/null || true

# --- strip: el binario sale con ~565 MB de simbolos de depuracion; quitarlos lo
# deja en decenas de MB, imprescindible para moverlo. Los simbolos se guardan
# aparte (TeaSpeakServer.debug) por si hiciera falta depurar un core mas adelante. ---
if [[ "${SKIP_STRIP:-0}" != "1" ]] && command -v strip >/dev/null 2>&1; then
    before=$(du -h "${BUNDLE}/TeaSpeakServer" | cut -f1)
    if command -v objcopy >/dev/null 2>&1; then
        objcopy --only-keep-debug "${BUNDLE}/TeaSpeakServer" "${SCRIPT_DIR}/TeaSpeakServer.debug" 2>/dev/null || true
    fi
    strip --strip-unneeded "${BUNDLE}/TeaSpeakServer"
    strip --strip-unneeded "${BUNDLE}/libteaspeak_rtc.so" "${BUNDLE}/libTeaMusic.so" 2>/dev/null || true
    strip --strip-unneeded "${BUNDLE}/libs/"* 2>/dev/null || true
    after=$(du -h "${BUNDLE}/TeaSpeakServer" | cut -f1)
    echo "  binario: ${before} -> ${after} (simbolos en ${SCRIPT_DIR}/TeaSpeakServer.debug)"
fi

cp -r "${ENV_DIR}/resources" "${BUNDLE}/resources"

# providers de musica (opcionales)
if [[ -d "${ENV_DIR}/providers" ]]; then
    cp -r "${ENV_DIR}/providers" "${BUNDLE}/providers"
fi

# geoloc (opcional, grande)
if [[ -d "${ENV_DIR}/geoloc" ]]; then
    cp -r "${ENV_DIR}/geoloc" "${BUNDLE}/geoloc"
fi

# config.yml: usa el que ya haya en el environment (tu plantilla de produccion).
# Se SANEAN las urls de base de datos para no filtrar credenciales en el bundle
# (install.sh las reescribe con la contrasena generada en cada instalacion).
if [[ -f "${ENV_DIR}/config.yml" ]]; then
    cp "${ENV_DIR}/config.yml" "${BUNDLE}/config.yml"
    python3 - "${BUNDLE}/config.yml" <<'PYEOF'
import sys, re
p = sys.argv[1]; c = open(p).read()
c = re.sub(r'(\n    url:).*',          r'\1 postgres://USER:PASSWORD@127.0.0.1:5432/teaspeak?connections=8', c, count=1)
c = re.sub(r'(\n    database_url:).*', r'\1 postgres://USER:PASSWORD@127.0.0.1:5432/teaspeak_logs?connections=4', c, count=1)
open(p,'w').write(c)
PYEOF
    echo "  config.yml copiado (urls de BD saneadas a placeholder)"
else
    echo "  AVISO: no hay config.yml en el environment; copia tu plantilla a ${BUNDLE}/config.yml"
fi

# protocol_key.txt es SENSIBLE. En modo PUBLIC=1 (para subir a GitHub) NO se incluye
# en el bundle; se deja como fichero aparte para distribuirlo en privado, y el
# instalador lo inyecta por separado.
if [[ -f "${ENV_DIR}/protocol_key.txt" ]]; then
    if [[ "${PUBLIC:-0}" == "1" ]]; then
        cp "${ENV_DIR}/protocol_key.txt" "${SCRIPT_DIR}/protocol_key.txt"
        chmod 600 "${SCRIPT_DIR}/protocol_key.txt"
        echo "  protocol_key.txt EXCLUIDO del bundle (modo PUBLIC); copiado aparte a ${SCRIPT_DIR}/protocol_key.txt"
    else
        cp "${ENV_DIR}/protocol_key.txt" "${BUNDLE}/protocol_key.txt"
        chmod 600 "${BUNDLE}/protocol_key.txt"
    fi
else
    echo "  AVISO: no hay protocol_key.txt; el servidor generara uno nuevo (los clientes TeamSpeak necesitan el correcto)."
fi

echo
echo "=== Bundle listo ==="
du -sh "${BUNDLE}"

# --- Empaquetar el desplegable completo (scripts + bundle) en un solo tar.gz ---
# Se excluyen los simbolos de depuracion (no van a produccion).
TARBALL="${SCRIPT_DIR}/teaspeak-deploy.tar.gz"
echo "=== Empaquetando ${TARBALL} ==="
tar -czf "${TARBALL}" \
    -C "${SCRIPT_DIR}" \
    --exclude='TeaSpeakServer.debug' \
    --exclude='teaspeak-deploy.tar.gz' \
    install.sh firewall.sh logs_retention.sh backup.sh make_bundle.sh bundle
echo "  $(du -h "${TARBALL}" | cut -f1)  ${TARBALL}"

echo
echo "=== Desplegar en una VPS Debian 11 limpia ==="
echo "  1. scp ${TARBALL}  root@NUEVA_VPS:/root/"
echo "  2. ssh root@NUEVA_VPS"
echo "  3. mkdir -p teaspeak-deploy && tar -xzf teaspeak-deploy.tar.gz -C teaspeak-deploy"
echo "  4. cd teaspeak-deploy && sudo ./install.sh"
echo
echo "  El protocol_key.txt va DENTRO del tarball: trata ese fichero como secreto"
echo "  (no lo subas a un sitio publico; usa scp o almacenamiento con acceso restringido)."
